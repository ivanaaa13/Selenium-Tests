package KupnjaFunti;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.*;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;


public class KupnjaFunti {
	
	public String baseUrl = "https://www.rba.hr/alati/tecajni-kalkulator/";
    String driverPath = "C:/Windows/chromedriver.exe";
    public WebDriver driver ;
    
		
		@Test
		public void launchBrowser() {
		
		System.setProperty("webdriver.chrome.driver", driverPath);
		 System.setProperty("webdriver.chrome.whitelistedIps", "");
		 ChromeOptions options = new ChromeOptions();
		 options.addArguments("--remote-allow-origins=*");
		 WebDriver driver = new ChromeDriver(options);
		driver.get("https://www.rba.hr/alati/tecajni-kalkulator/");
		driver.manage().window().maximize();
		
		//accept cookies
		WebElement btn = driver.findElement(By.id("onetrust-accept-btn-handler"));
	      btn.click();
	      
	      
	      //kupovni
	      WebElement kpn = driver.findElement(By.id("kurs"));
			Select select = new Select(kpn);
			select.selectByVisibleText("Kupovni");
			
			//valuta1
			WebElement val1 = driver.findElement(By.id("val1"));
			Select select1 = new Select(val1);
			select1.selectByVisibleText("EUR");
			
			//valuta2
			WebElement val2 = driver.findElement(By.id("val2"));
			Select select2 = new Select(val2);
			select2.selectByVisibleText("GBP");
			
			//input suma
			WebElement suma = driver.findElement(By.id("suma1"));
			suma.clear();
			suma.sendKeys("140");
			WebElement klik = driver.findElement(By.id("content"));
			klik.click();
			klik.click();
			
			//tecaj i konacni iznos
			WebElement tecaj = driver.findElement(By.id("rateExch"));
			String tecaj1 = tecaj.getText();
			
			try {
			    Thread.sleep(10000); // sleep for 10 seconds
			} catch (InterruptedException e) {
			    e.printStackTrace();
			}

			
			WebElement konacni = driver.findElement(By.id("toHouseExch"));
			String konacni1 = konacni.getText();
			
			String pattern = "(\\d+\\.\\d{2}) EUR = (\\d+\\.\\d{2}) GBP";
			Pattern regex = Pattern.compile(pattern);
			Matcher matcher = regex.matcher(konacni1);

			String eurValue = null;
			String gbpValue = null;
			
			if (matcher.find()) {
			    eurValue = matcher.group(1);
			    gbpValue = matcher.group(2);
			    System.out.println("EUR value: " + eurValue);
			    System.out.println("GBP value: " + gbpValue);
			} else {
			    System.out.println("Pattern not found in text.");
			}
			

			System.out.println("Tecaj je " + tecaj1 + ", a za " + eurValue + " eura dobijem " + gbpValue + " funti.");
			
			
		}
	
	 

}
    