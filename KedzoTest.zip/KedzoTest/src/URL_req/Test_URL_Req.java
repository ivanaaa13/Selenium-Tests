package URL_req;

import java.io.BufferedReader;
import java.net.URL;

import java.net.*;
import java.io.InputStreamReader;

import org.json.JSONObject;
import org.json.XML;

public class Test_URL_Req {
public static void main(String[] args) {
		
		try {
		
		String url ="https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=Raiffeisen&srlimit=10&format=json&formatversion=2";
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection)obj.openConnection();
		
	    BufferedReader in = new BufferedReader(
	    		new InputStreamReader(con.getInputStream()));
	    String inputLine;
	    StringBuffer response = new StringBuffer();
	    while ((inputLine = in.readLine()) != null) {
	    	response.append(inputLine);
	    }
	    in.close();
	    System.out.println("JSON: " + response.toString());
	    
	    JSONObject json = new JSONObject(response.toString());
	    String xml="";
	    xml=xml+XML.toString(json);
	    System.out.println("XML code: " + xml);
	
	} catch (Exception e) {
		System.out.println(e);
	}
	}

}
